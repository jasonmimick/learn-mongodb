SlideSync.init(SlideDeck);
SlideController.init(SlideSync);
